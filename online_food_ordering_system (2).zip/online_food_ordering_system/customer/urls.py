from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from customer.views import CustomerRegister,CustomerListing,CustomerDeleteView,CustomerUpdateView

urlpatterns = [
path(r'register/',CustomerRegister.as_view(),name='cust_reg'),
path(r'custlist/',CustomerListing.as_view(),name='cust_list'),
path(r'delete/(?P<pk>[0-9]+)/$',CustomerDeleteView.as_view(),name='delete_details'),
path(r'update/(?P<pk>[0-9]+)/$',CustomerUpdateView.as_view(),name='update_details'),


]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)


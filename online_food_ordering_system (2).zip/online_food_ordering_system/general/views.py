from django.shortcuts import render,redirect

from django.views.generic import TemplateView,View,TemplateView,TemplateView,TemplateView,View,View,View,UpdateView,View,View,View,View
from general.models import ContactModel,FoodCategoryModel,CategoryModel
from general.forms import ContactForm,FoodForm,CategoryForm
# Create your views here.
class HomePageView(TemplateView):
	template_name='index.html'

class ContactUsView(View):
	template_name = 'contact2.html'
	form_class =ContactForm

	def get(self,request):
		form = self.form_class()
		context ={
		'conct_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			book_cat = ContactModel.objects.create(
				name = request.POST.get('name'),
				email = request.POST.get('email'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)
			return redirect('/general/contactsucess/')
		else:
			form=self.form_class()
			return render(request,self.template_name,{'form':form})

class ContactSucessView(TemplateView):
	template_name = 'contactsuccess.html'
class AboutUsView(TemplateView):
	template_name = 'aboutus.html'

class AdminPageView(TemplateView):
	template_name = 'admin1.html'

class FoodPageView(View):
	template_name = 'food.html'
	form_class =FoodForm

	def get(self,request):
		form = self.form_class()
		context ={
		'food_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			cat_obj = CategoryModel.objects.get(id=request.POST.get('food_category'))
			food = FoodCategoryModel.objects.create(
				title=request.POST.get('title'),
				description=request.POST.get('description'),
				food_category=cat_obj,
				price = request.POST.get('price'),
				
				)
			return redirect('/general/aboutus/')
		else:
			form=self.form_class()
			return render(request,self.template_name,{'form':form})

class ListFoodView(View):
	template_name = 'food_card1.html'
	def get(self,request):
		food_list = FoodCategoryModel.objects.all()
		context = {
		'food' :food_list
		} 
		return render(request,self.template_name,context)

class FoodDetailView(View):
	template_name = 'food_detail.html'
	def get(self,request,pk):
		obj = FoodCategoryModel.objects.get(id=pk)
		context = {
		'foodd' :obj
		}
		return render(request,self.template_name,context)

class FoodDeleteView(View):
	template_name = 'food_card1.html'
	def get(self,request,pk):
		cat_obj = FoodCategoryModel.objects.get(id=pk).delete()
		food_list = FoodCategoryModel.objects.all()
		context = {
		'food' :food_list
		}
		return render(request,self.template_name,context)

class FoodUpdateView(UpdateView):
	model = FoodCategoryModel
	fields = ['title','description','food_category','price']
	template_name = 'updatefood.html'
	success_url = '/general/index/'

class CategoryView(View):
	template_name = 'category.html'
	form_class =CategoryForm

	def get(self,request):
		form = self.form_class()
		context ={
		'category_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			food = CategoryModel.objects.create(
				food_category=request.POST.get('food_category'),
				)
			return redirect('/general/categorylist/')
		else:
			form=self.form_class()
			return render(request,self.template_name,{'form':form})

class ListCategoryView(View):
	template_name = 'category_list1.html'
	def get(self,request):
		cat_list = CategoryModel.objects.all()
		context = {
		'food' :cat_list
		} 
		return render(request,self.template_name,context)

class CategoryDetailView(View):
	template_name = 'category_detail.html'
	def get(self,request,pk):
		obj = CategoryModel.objects.get(id=pk)
		context = {
		'foodd' :obj
		}
		return render(request,self.template_name,context)

class CategoryDeleteView(View):
	template_name = 'category_list1.html'
	def get(self,request,pk):
		cat_obj = CategoryModel.objects.get(id=pk).delete()
		cat_list = CategoryModel.objects.all()
		context = {
		'food' :cat_list
		}
		return render(request,self.template_name,context)



from django.contrib import admin

from general.models import ContactModel,CategoryModel,FoodCategoryModel

# Register your models here.
admin.site.register(ContactModel)
admin.site.register(CategoryModel)
admin.site.register(FoodCategoryModel)

